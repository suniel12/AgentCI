"""
LangGraph Adapter.
"""
from .base import BaseAdapter

class LangGraphAdapter(BaseAdapter):
    pass
