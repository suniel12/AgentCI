"""
Adapter registry and base classes.
"""
